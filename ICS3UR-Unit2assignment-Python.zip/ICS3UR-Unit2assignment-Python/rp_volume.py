#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program calculates the volume of a rectangular prism
# where the user gets to enter the length, width and depth in m

import math


def main():
    # main function
    print("We will be calculating the volume of a rectangular prism. ")
    # input
    length = int(input("Enter the length (m): "))
    width = int(input("Enter the width (m): "))
    depth = int(input("Enter the depth (m): "))
    # process
    volume = length * width * depth
    # output
    print("Volume is {} m^3".format(volume))


if __name__ == "__main__":
    main()
